# How to Fish 32-bit

Ini adalah **prototype/rebuild 32-bit yang berdiri sendiri**, bukan konversi binary dari APK ARM64 asli.

## Target perangkat
- Android 6.0+ (API 23+)
- Tidak membawa `.so` native sama sekali
- Dapat berjalan pada perangkat Android 32-bit ARM karena aplikasi menggunakan Java/Android Canvas APIs

## Isi prototype
- 5 map/quest
- Fish biasa dan Boss Fish di map 5
- Kontrol sentuh CAST / REEL
- Animasi tangan/kail sederhana
- Efek suara beep tanpa file native
- Sistem tangkap ikan + coin + pergantian map

## Build APK
Gunakan Android Studio atau GitHub Actions. Workflow sudah tersedia di `.github/workflows/build.yml`.

Catatan penting: APK asli yang dikirim berisi library ARM64 (`arm64-v8a`) seperti `libil2cpp.so` dan `libunity.so`. Library tersebut tidak dapat diubah menjadi ARMv7 hanya dengan repack/rename. Karena itu project ini adalah rebuild 32-bit yang dapat dikembangkan lebih jauh.
