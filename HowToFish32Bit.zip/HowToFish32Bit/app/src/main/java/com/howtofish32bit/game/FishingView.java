package com.howtofish32bit.game;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

public class FishingView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private ToneGenerator tone;
    private int map = 1, fish = 0, goal = 3, coins = 0, power = 0;
    private boolean cast = false, hooked = false, boss = false, victory = false;
    private float rodX, rodY, lineT = 0, bobberX, bobberY;
    private long last = System.currentTimeMillis();
    private String quest = "Catch 3 fish";
    private final String[] maps = {"Sunrise Lake","Reed Marsh","Blue Bay","Storm River","Boss Lagoon"};

    public FishingView(Context c) {
        super(c); setFocusable(true);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 55); } catch(Exception ignored) {}
    }

    private void beep(int freq, int ms) { if(tone!=null) try { tone.startTone(ToneGenerator.TONE_PROP_BEEP, ms); } catch(Exception ignored) {} }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w=getWidth(), h=getHeight();
        float dt=Math.min(0.04f,(System.currentTimeMillis()-last)/1000f); last=System.currentTimeMillis();
        drawWorld(c,w,h);
        drawPlayer(c,w,h);
        drawHud(c,w,h);
        drawControls(c,w,h);
        if (cast) { lineT += dt*1.5f; if(lineT>1.0f) lineT=1.0f; }
        if (cast && !hooked && lineT>0.8f && rng.nextFloat()<dt*0.35f) { hooked=true; fish++; coins += boss?50:5; beep(880,120); }
        if (hooked && rng.nextFloat()<dt*0.9f) { hooked=false; cast=false; power=0; if(fish>=goal && !boss){ if(map<5){ map++; fish=0; goal=map==5?1:3; quest=map==5?"Defeat Boss Fish":"Catch 3 fish"; } else victory=true; } }
        if(!victory) postInvalidateOnAnimation();
    }

    private void drawWorld(Canvas c,int w,int h){
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(135,206,235)); c.drawRect(0,0,w,h*0.45f,p);
        p.setColor(Color.rgb(245,220,135)); c.drawRect(0,h*0.42f,w,h,p);
        p.setColor(Color.rgb(55,155,205)); c.drawRect(0,h*0.50f,w,h,p);
        // distant hills
        Path hills=new Path(); hills.moveTo(0,h*.48f); hills.quadTo(w*.2f,h*.32f,w*.38f,h*.48f); hills.quadTo(w*.58f,h*.34f,w*.78f,h*.48f); hills.quadTo(w*.92f,h*.38f,w,h*.48f); hills.close();
        p.setColor(Color.rgb(80,155,90)); c.drawPath(hills,p);
        // sun
        p.setColor(Color.YELLOW); c.drawCircle(w*.86f,h*.14f,42,p);
        p.setColor(Color.argb(120,255,255,255)); c.drawCircle(w*.12f,h*.18f,30,p); c.drawCircle(w*.17f,h*.14f,22,p);
        // water ripples
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.argb(120,255,255,255));
        for(int i=0;i<7;i++){ float y=h*.58f+i*h*.055f; c.drawOval(w*.55f,y,w*.75f,y+15,p); }
        p.setStyle(Paint.Style.FILL);
        // map decoration
        p.setColor(Color.rgb(35,105,70));
        for(int i=0;i<6;i++) c.drawRect(30+i*110,h*.38f,45+i*110,h*.52f,p);
    }

    private void drawPlayer(Canvas c,int w,int h){
        float px=w*.19f, py=h*.62f;
        // body
        p.setColor(Color.rgb(45,70,125)); c.drawRoundRect(px-35,py,px+35,py+105,18,18,p);
        p.setColor(Color.rgb(244,196,145)); c.drawCircle(px,py-25,27,p);
        p.setColor(Color.rgb(35,35,45)); c.drawArc(px-31,py-52,px+31,py-2,180,180,true,p);
        // arm animation
        float arm = (float)Math.sin(System.currentTimeMillis()/220.0)*8f;
        p.setStrokeWidth(14); p.setColor(Color.rgb(244,196,145));
        c.drawLine(px+20,py+22,px+72,py+55+arm,p);
        p.setStrokeWidth(8); p.setColor(Color.rgb(70,45,25));
        c.drawLine(px+65,py+55+arm, w*.49f, h*.40f,p);
        // rod tip and bobber
        if(cast){ float bx=w*.53f, by=h*.61f; bobberX=bx; bobberY=by; p.setStrokeWidth(4); p.setColor(Color.WHITE); c.drawLine(w*.49f,h*.40f,bx,by,p); p.setColor(Color.RED); c.drawCircle(bx,by,8,p); }
    }

    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){ p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT); p.setTextSize(size); p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawText(s,x,y,p); }
    private void box(Canvas c,float l,float t,float r,float b,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,18,18,p);}

    private void drawHud(Canvas c,int w,int h){
        box(c,20,18,430,100,Color.argb(205,0,0,0));
        text(c,maps[map-1],40,52,26,Color.WHITE,true);
        text(c,"Quest: "+quest,40,82,18,Color.WHITE,false);
        text(c,"Fish: "+fish+"/"+goal+"   Coins: "+coins, w-300,45,20,Color.WHITE,true);
        if(hooked){ box(c,w*.35f,22,w*.65f,78,Color.argb(210,210,40,40)); text(c,boss?"BOSS HOOKED!":"FISH ON!",w*.41f,58,24,Color.WHITE,true); }
        if(victory){ box(c,w*.24f,h*.28f,w*.76f,h*.73f,Color.argb(235,0,0,0)); text(c,"QUEST COMPLETE",w*.36f,h*.40f,34,Color.WHITE,true); text(c,"All 5 maps cleared!",w*.35f,h*.50f,24,Color.WHITE,false); text(c,"Coins: "+coins,w*.43f,h*.58f,26,Color.YELLOW,true); text(c,"Tap CAST to play again",w*.35f,h*.67f,18,Color.WHITE,false); }
    }

    private void drawControls(Canvas c,int w,int h){
        box(c,25,h-135,165,h-25,Color.argb(185,0,0,0));
        text(c,"◀",70,h-65,46,Color.WHITE,true); text(c,"▶",115,h-65,46,Color.WHITE,true);
        box(c,w-230,h-150,w-30,h-35,Color.argb(210,15,90,170));
        text(c,"CAST",w-190,h-80,30,Color.WHITE,true);
        box(c,w-420,h-125,w-260,h-35,Color.argb(180,0,0,0));
        text(c,"REEL",w-390,h-70,24,Color.WHITE,true);
    }

    @Override public boolean onTouchEvent(MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_DOWN && e.getAction()!=MotionEvent.ACTION_UP) return true; if(e.getAction()!=MotionEvent.ACTION_DOWN) return true;
        float x=e.getX(), y=e.getY(); int w=getWidth(),h=getHeight();
        if(victory){ if(x>w-250 && y>h-180){ victory=false; map=1; fish=0; coins=0; goal=3; quest="Catch 3 fish"; } return true; }
        if(y>h-170 && x>w-245){
            cast=true; lineT=0; boss=(map==5); beep(660,90); return true;
        }
        if(y>h-150 && x>w-445 && x<w-245){ if(cast){ power=Math.min(100,power+20); if(power>=80){ hooked=false; cast=false; beep(440,80);} } return true; }
        if(y>h-155 && x<190){ beep(520,50); return true; }
        return true;
    }
}
